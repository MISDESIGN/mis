package cn.edu.cumt.ec.service;

import java.util.ArrayList;
import java.util.List;

import cn.edu.cumt.ec.dao.NewsDao;

import cn.edu.cumt.ec.entity.News;

public class NewsService {
	public NewsService() {
		super();
	}
	private NewsDao newsDao;

	public void setNewsDao(NewsDao newsDao) {
		this.newsDao = newsDao;
	}
	
	public NewsService(NewsDao newsDao){
		this.newsDao = newsDao;
	}
	public boolean add(News news){
		return newsDao.add(news);
	}
	public boolean update(News oldNews,News newNews){
		return newsDao.update(oldNews, newNews);
	}
	public boolean delete(News news){
		return newsDao.delete(news);
	}
	public List<News> getAll(){
		return newsDao.getAll();
	}
	public List<News> getUser(){
		return newsDao.getUser();
	}
	public List<News> getReceivegoods(){
		return newsDao.getReceivegoods();
	}
	public String find(News news){
		return newsDao.find(news);
	}
	public String findGoods(News news){
		return newsDao.findGoods(news);
	}
	public News findByNo(News news){
		return newsDao.findByNo(news);
	}
	public News findByPhone(News news){
		return newsDao.findByPhone(news);
	}
	public ArrayList<News> getAllKd()
	{
		return newsDao.getAllKd();
		
	}
	public ArrayList<News> getSendNews(String phone)
	{
		return newsDao.getSendNews(phone);
		
	}

	public boolean updateAddress(News oldNews, News newNews) {
		// TODO Auto-generated method stub
		return newsDao.updateAddress(oldNews,newNews);
	}
}
