package cn.edu.cumt.ec.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.edu.cumt.ec.dbutil.DbUtil;

import cn.edu.cumt.ec.entity.News;

public class NewsDaoJDBCImpl implements NewsDao {

	@Override
	//�û�ע��
	public boolean add(News news) {
		// TODO Auto-generated method stub
		return DbUtil.executeUpdate("insert into user values(?,?,?)",new Object[]{news.getUsername(),news.getPassword(),news.getEmail()});		
	}
//�û���¼


	@Override
	//�޸�����
	public boolean update(News oldNews,News newNews) {
		// TODO Auto-generated method stub
		return DbUtil.executeUpdate("update details set details.signname=? where no=? and companyid=(select companyid from company where company=?)",new Object[]{newNews.getSignname(),oldNews.getNo(),oldNews.getCompany()});
	}
	public boolean updateAddress(News oldNews,News newNews) {
		// TODO Auto-generated method stub
		return DbUtil.executeUpdate("update user set address=? where phone=? ",new Object[]{newNews.getAddress(),oldNews.getPhone()});
	}
	@Override
	//�һ�����
	public String find(News news) {
		// TODO Auto-generated method stub
		return DbUtil.executeQueryReturnString("select password from user where username=?  and email=?",new Object[]{news.getUsername(),news.getEmail()});
	}
	public String findGoods(News news) {
		// TODO Auto-generated method stub
		return DbUtil.executeQueryReturnString("select receiver from details,company where details.companyid=company.companyid and company=? and no=?",new Object[]{news.getCompany(),news.getNo()});
	}
	
	@Override
	//ɾ���û�
	public boolean delete(News news) {
		// TODO Auto-generated method stub
		return DbUtil.executeUpdate("delete from user where usernmae=?)",new Object[]{news.getUsername()});
	}

	//��ȡ�����û�
	@Override
	public List<News> getAll() {
		// TODO Auto-generated method stub
		ResultSet rs=DbUtil.executeQuery("select * from worker", new Object[]{});
		List<News> newsList=new ArrayList<News>();
		try{
			while(rs.next()){
				News news=new News();
				news.setWorkername(rs.getString(1));
				news.setPassword(rs.getString(2));
				newsList.add(news);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return newsList;
	}
	
	public List<News> getUser() {
		// TODO Auto-generated method stub
		ResultSet rs=DbUtil.executeQuery("select * from user", new Object[]{});
		List<News> newsList=new ArrayList<News>();
		try{
			while(rs.next()){
				News news=new News();
				news.setUsername(rs.getString(1));
				news.setPassword(rs.getString(2));
				newsList.add(news);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return newsList;
	}
	public List<News> getReceivegoods() {
		// TODO Auto-generated method stub
		ResultSet rs=DbUtil.executeQuery("select no,company,receiver,signname from details,company where details.companyid=company.companyid", new Object[]{});
		List<News> newsList=new ArrayList<News>();
		try{
			while(rs.next()){
				News news=new News();
				news.setNo(rs.getInt(1));
				news.setCompany(rs.getString(2));
				news.setReceiver(rs.getString(3));
				news.setSignname(rs.getString(4));
				newsList.add(news);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return newsList;
	}
	
	public News findByNo(News news) {
		// TODO Auto-generated method stub
		ResultSet rs = DbUtil.executeQuery("select no,company,receiver,signname from details,company where details.companyid=company.companyid and no=? and company=?",
				new Object[] {news.getNo(),news.getCompany()});
	
			News news1=null;
			try {
				while (rs.next()) {
					news1=new News();
					news1.setNo(rs.getInt(1));
					news1.setCompany(rs.getString(2));
					news1.setReceiver(rs.getString(3));
					news1.setSignname(rs.getString(4));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return news1;
	}
	public News findByPhone(News news) {
		// TODO Auto-generated method stub
		ResultSet rs = DbUtil.executeQuery("select NO,company,receiver,signname from details,company where details.companyid=company.companyid and receivertel=? ",
				new Object[] {news.getReceivertel()});
	
			News news1=null;
			try {
				while (rs.next()) {
					news1=new News();
					news1.setNo(rs.getInt(1));
					news1.setCompany(rs.getString(2));
					news1.setReceiver(rs.getString(3));
					news1.setSignname(rs.getString(4));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return news1;
	}
	public ArrayList<News> getAllKd() {
		// TODO Auto-generated method stub
		ResultSet rs=DbUtil.executeQuery("select receiver,receivertel,address,company,NO from details,company,user where user.phone=details.receivertel and details.companyid=company.companyid and details.std=1 and signname=''  order by address ", new Object[]{});
		ArrayList<News> itemsList=new ArrayList<News>();
		try{
			while(rs.next()){
				News items=new News();
				items.setUsername(rs.getString(1));
				items.setReceivertel(rs.getString(2));
				items.setAddress(rs.getString(3));
				items.setCompany(rs.getString(4));
				items.setNo(rs.getInt(5));
				itemsList.add(items);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return itemsList;
	}
	public ArrayList<News> getSendNews(String phone) {
		// TODO Auto-generated method stub
		ResultSet rs=DbUtil.executeQuery("select company,NO,id from details,company,user where user.phone=details.receivertel and details.companyid=company.companyid and phone=? order by no", new Object[]{phone});
		ArrayList<News> newsList=new ArrayList<News>();
		try{
			while(rs.next()){
				News news=new News();
				
				news.setId(rs.getInt(3));
				news.setCompany(rs.getString(1));
				news.setNo(rs.getInt(2));
				newsList.add(news);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return newsList;
	}
	
}



