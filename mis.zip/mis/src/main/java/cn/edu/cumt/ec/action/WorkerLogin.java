
package cn.edu.cumt.ec.action;


import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import cn.edu.cumt.ec.dao.NewsDaoJDBCImpl;
import cn.edu.cumt.ec.entity.News;
import cn.edu.cumt.ec.service.NewsService;


public class WorkerLogin extends ActionSupport {
	private NewsService newsService=new NewsService();
	private String workername;
	private String password;
	public String isUseCookie;
	static int online;
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getWorkername() {
		return workername;
	}
	public void setWorkername(String workername) {
		this.workername = workername;
	
	}
	public NewsService getNewsService() {
		return newsService;
	}
	public void setNewsService(NewsService newsService) {
		this.newsService = newsService;
	}
	@Override
	public String execute() {
		NewsDaoJDBCImpl newsDaoJDBCImpl=new NewsDaoJDBCImpl();
		newsService.setNewsDao(newsDaoJDBCImpl);
		 ActionContext news1=ActionContext.getContext();
	     News news=new News();
	     news.setWorkername(getWorkername());
 	     news.setPassword(getPassword()); 
         System.out.println(isUseCookie);
         if(isUseCookie!=null){
             Cookie workernameCookie = new Cookie("workername",workername);
             Cookie passwordCookie = new Cookie("password",password);
             workernameCookie.setMaxAge(864000);
             passwordCookie.setMaxAge(864000);
             ServletActionContext.getResponse().addCookie(workernameCookie);
             ServletActionContext.getResponse().addCookie(passwordCookie);
         }
         else{
        	 HttpServletRequest request = ServletActionContext.getRequest();
        	 Cookie[] cookies = request.getCookies();
        	 if(cookies!=null){
        		 for(Cookie c:cookies)
                 {
                    if(c.getName().equals("workername")||c.getName().equals("password"))
                    {
                        c.setMaxAge(0); //����CookieʧЧ
                        ServletActionContext.getResponse().addCookie(c); //���±��档
                    }
                 }
        	 }
         }
 	     List<News> newsList=newsService.getAll();
// 	     for(News a:newsList){
// 	    	 System.out.println(a.getUsername()+":"+a.getPassword());
// 	     }
 	     int count=0;
 	     
	     for(int i=0;i<newsList.size();i++){
	    	 System.out.println(newsList.get(i).getPassword());
	    	 if(news.getWorkername().equals(newsList.get(i).getWorkername())&&news.getPassword().equals(newsList.get(i).getPassword())){
	    		 count=count+1;
	    	 }
	    	}
	     System.out.println(count);
	     if(count!=0){
	    	 ActionContext b=ActionContext.getContext();
		     b.getSession().put("denglu", news.getWorkername());	    	 
		     online=online+1;
		     b.getApplication().put("online",online);
	    	 return SUCCESS;
	     }
	     else{
	    	 return ERROR;
	     }
	  
	  
	}
}
