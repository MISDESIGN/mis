package cn.edu.cumt.ec.action;

import java.util.List;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import cn.edu.cumt.ec.dao.NewsDaoJDBCImpl;
import cn.edu.cumt.ec.entity.News;
import cn.edu.cumt.ec.service.NewsService;

public class Search1 extends ActionSupport {
	public NewsService newsService=new NewsService();
	public String company;
	public String signname;
	public String receiver;
	public String receivertel;
	public int no;
    public NewsDaoJDBCImpl daoJDBCImpl=new NewsDaoJDBCImpl();
	
	public String getReceivertel() {
		return receivertel;
	}
	public void setReceivertel(String receivertel) {
		this.receivertel = receivertel;
	
	}
	public NewsService getNewsService() {
		return newsService;
	}
	public void setNewsService(NewsService newsService) {
		this.newsService = newsService;
	}
	@Override
	public String execute() throws Exception{
		
		NewsService NewsService=new NewsService();
		News news=new News();
		news.setReceivertel(receivertel);
		
		News news1=daoJDBCImpl.findByPhone(news);
		System.out.println(news1.getNo()+news1.getCompany()+news1.getReceiver()+news1.getSignname()+"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
	    ActionContext.getContext().put("a", news1.getNo());
	    ActionContext.getContext().put("b", news1.getCompany());
	    ActionContext.getContext().put("c", news1.getReceiver());
	    ActionContext.getContext().put("d", news1.getSignname());
	    
		return SUCCESS;
		

		
	  
	}
}