
package cn.edu.cumt.ec.action;


import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import cn.edu.cumt.ec.dao.NewsDaoJDBCImpl;
import cn.edu.cumt.ec.entity.News;
import cn.edu.cumt.ec.service.NewsService;


public class UserLogin extends ActionSupport {
	private NewsService newsService=new NewsService();
	private String username;
	private String password;
	public String isUseCookie;
	static int online;
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	
	}
	public NewsService getNewsService() {
		return newsService;
	}
	public void setNewsService(NewsService newsService) {
		this.newsService = newsService;
	}
	@Override
	public String execute() {
		NewsDaoJDBCImpl newsDaoJDBCImpl=new NewsDaoJDBCImpl();
		newsService.setNewsDao(newsDaoJDBCImpl);
		 ActionContext news1=ActionContext.getContext();
	     News news=new News();
	     news.setUsername(getUsername());
 	     news.setPassword(getPassword()); 
         System.out.println(isUseCookie);
         if(isUseCookie!=null){
             Cookie usernameCookie = new Cookie("username",username);
             Cookie passwordCookie = new Cookie("password",password);
             usernameCookie.setMaxAge(864000);
             passwordCookie.setMaxAge(864000);
             ServletActionContext.getResponse().addCookie(usernameCookie);
             ServletActionContext.getResponse().addCookie(passwordCookie);
         }
         else{
        	 HttpServletRequest request = ServletActionContext.getRequest();
        	 Cookie[] cookies = request.getCookies();
        	 if(cookies!=null){
        		 for(Cookie c:cookies)
                 {
                    if(c.getName().equals("username")||c.getName().equals("password"))
                    {
                        c.setMaxAge(0); //����CookieʧЧ
                        ServletActionContext.getResponse().addCookie(c); //���±��档
                    }
                 }
        	 }
         }
 	     List<News> newsList=newsService.getUser();

 	     int count=0;
 	     
	     for(int i=0;i<newsList.size();i++){
	    	 System.out.println(newsList.get(i).getPassword());
	    	 if(news.getUsername().equals(newsList.get(i).getUsername())&&news.getPassword().equals(newsList.get(i).getPassword())){
	    		 count=count+1;
	    	 }
	    	}
	     System.out.println(count);
	     if(count!=0){
	    	 ActionContext b=ActionContext.getContext();
		     b.getSession().put("denglu", news.getUsername());	    	 
		     online=online+1;
		     b.getApplication().put("online",online);
	    	 return SUCCESS;
	     }
	     else{
	    	 return ERROR;
	     }
	  
	  
	}
}
