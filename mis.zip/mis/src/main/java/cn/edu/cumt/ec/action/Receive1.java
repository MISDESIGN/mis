package cn.edu.cumt.ec.action;

import java.util.List;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import cn.edu.cumt.ec.dao.NewsDaoJDBCImpl;
import cn.edu.cumt.ec.entity.News;
import cn.edu.cumt.ec.service.NewsService;

public class Receive1 extends ActionSupport {
	public NewsService newsService=new NewsService();
	public String company;
	public String signname;
	public String receiver;
	public int no;
    public NewsDaoJDBCImpl daoJDBCImpl=new NewsDaoJDBCImpl();
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	
	}
	public NewsService getNewsService() {
		return newsService;
	}
	public void setNewsService(NewsService newsService) {
		this.newsService = newsService;
	}
	@Override
	public String execute() throws Exception{
		
		NewsService NewsService=new NewsService();
		News news=new News();
		System.out.println(company+"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
		news.setCompany(company);
		news.setNo(no);
		News news1=daoJDBCImpl.findByNo(news);
	    ActionContext.getContext().put("no", news1.getNo());
	    ActionContext.getContext().put("company", news1.getCompany());
	    ActionContext.getContext().put("receiver", news1.getReceiver());
		return SUCCESS;
	}
}