package cn.edu.cumt.ec.dao;

import java.util.ArrayList;
import java.util.List;

import cn.edu.cumt.ec.entity.*;
import cn.edu.cumt.ec.entity.News;
//�ӿ�
public interface NewsDao {
	//ע��
	public boolean add(News news);
	//��������
	public boolean update(News oldNews,News newNews);
	//ɾ���û�
	public boolean delete(News news);
	//��ȡ�����û�
	public List<News> getAll();
	public List<News> getUser();
	public List<News> getReceivegoods();
	//�һ�����
	public String find(News news);
	public String findGoods(News news);
	public News findByNo(News news);
	public News findByPhone(News news);
	public ArrayList<News> getAllKd();
	public ArrayList<News> getSendNews(String phone);
	public boolean updateAddress(News oldNews,News newNews);



	
}
