package cn.edu.cumt.ec.action;

import java.util.List;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Result;

import cn.edu.cumt.ec.dao.NewsDaoJDBCImpl;
import cn.edu.cumt.ec.entity.News;
import cn.edu.cumt.ec.service.NewsService;

public class Receive2 extends ActionSupport {
	private NewsService newsService=new NewsService();
	private String company;
	private String signname;
	private String oldsignname;
	private int no;
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getSignname() {
		return signname;
	}
	public void setSignname(String signname) {
		this.signname = signname;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no= no;
	
	}
	public NewsService getNewsService() {
		return newsService;
	}
	public void setNewsService(NewsService newsService) {
		this.newsService = newsService;
	}
	@Override
	public String execute() throws Exception{
		NewsDaoJDBCImpl newsDaoJDBCImpl=new NewsDaoJDBCImpl();
		newsService.setNewsDao(newsDaoJDBCImpl);		
	     News oldNews=new News();
	     News newNews=new News();
	     oldNews.setCompany(getCompany());
 	     oldNews.setNo(getNo());
 	     oldNews.setSignname(getOldSignname());
 	     newNews.setCompany(getCompany());
 	     newNews.setSignname(getSignname());
 	     List<News> newsList=newsService.getAll();
 	     ActionContext b=ActionContext.getContext();
 	     System.out.println("��˾��"+oldNews.getCompany());
 	    System.out.println("ǩ���ˣ�"+newNews.getSignname());
 	   System.out.println("��ţ�"+oldNews.getNo());
 	   
 	   
 	    int count=0;
	     for(int i=0;i<newsList.size();i++){
	    	 if(newsService.update(oldNews, newNews)){
	    		 count=count+1;
	    		 
	    	 }
	    	}
	     System.out.println(count);
	     if(count!=0){
	    	 b.put("result", "�ɹ���");
	    	 return SUCCESS;
	    	 
	     }
	     else{
	    	 b.put("result", "ʧ�ܣ�");
	    	 return SUCCESS;
	     }
	     
		}
	public String getOldSignname() {
		return oldsignname;
	}
	public void setOldpassword(String signname) {
		this.oldsignname = signname;
	}

	}
	